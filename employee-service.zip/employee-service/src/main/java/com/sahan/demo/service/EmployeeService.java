package com.sahan.demo.service;

import java.util.List;

import com.sahan.demo.modal.Employee;

public interface EmployeeService {

	Employee save(Employee employee);
	List<Employee> fetchAllEmployees();
	Employee fetchEmployee(Employee employee);
}
